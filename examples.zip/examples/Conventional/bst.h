// Kapral, Maxwell
// CSCI 311 Thurs. Lab
// Project 1
// bst.h [ISO C++11]

#include <iostream>
#include <string>
#include <vector>
using namespace std;

#include "tnode.h"
#ifndef BST_H
#define BST_H

class BST{
    public:
        BST():  root(nullptr) {};
        ~BST(){
            clean(root);
            root = nullptr;
        };       
		void insert(string akey, string aval){
			if(root != nullptr){
                root = insert(root, akey, aval);
            }else
                root = new Tnode(akey, aval);
		};
        void print_inorder(){
            print_inorder(root);
            cout << endl;
        };
		void findPrint(string akey){ findPrint(root, akey); };
		void heightPrint(){ 
            heightPrint(root); 
			cout << endl;
		};
		void printBF(){
			printBF(root);
			cout << endl;
		};
		void remove(string ak){ root = remove(root, ak); };
        void printSize(){
            printSize(root);
            cout << endl;
        };
        Tnode* findNode(string akey){ return findNode(root, akey); };
        string findLCA(string ak1, string ak2){ return findLCA(root, ak1, ak2); };
        string findKthSmallest(int k){ return findKthSmallest(root, k); };
        void printLongestPath(){ return printLongestPath(root); };
        void collectSubtree(string akey, vector<string> &v){
            Tnode *cur = findNode(akey);
            if(cur != nullptr)
                collecTree(cur, v);
        };
	private:
		Tnode* remove(Tnode* cur, string ak);
		Tnode* getleftmost(Tnode* cur);
		void printBF(Tnode *cur);
		int getHeight(Tnode *cur){
            if(cur == nullptr)
                return -1;
            else
                return cur->height;
        };
		void updateHeight(Tnode *cur);
		int balanceFactor(Tnode *cur);
		Tnode* rightRotation(Tnode *cur);
		Tnode* leftRotation(Tnode *cur);
		void heightPrint(Tnode *cur);
		Tnode* insert(Tnode *cur, string akey, string aval);
		void print_inorder(Tnode *cur);
		Tnode *root = nullptr;
		void clean(Tnode* cur);
		Tnode* copy(Tnode* cur);
		void findPrint(Tnode* cur, string akey);
        Tnode* findNode(Tnode* cur, string key);
		Tnode* restoreBalance(Tnode* cur);
        int getSize(Tnode* cur){
            if(cur != nullptr)
                return cur->size;
            else
                return 0;
        };
        void updateSize(Tnode *cur){
            if(cur != nullptr)
                cur->size = getSize(cur->left) + getSize(cur->right) + 1;
        };
        void printSize(Tnode *cur){
            if(cur != nullptr){
                printSize(cur->left);
                cout << cur->size << " ";
                printSize(cur->right);
            }
        };
        string findLCA(Tnode *cur, string akey1, string akey2);
        string findKthSmallest(Tnode *cur, int k);
        void printLongestPath(Tnode *cur);
        void collecTree(Tnode *cur, vector<string> &result);
};

#endif
