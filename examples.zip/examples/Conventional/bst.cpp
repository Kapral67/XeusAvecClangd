// Kapral, Maxwell
// CSCI 311 Thurs. Lab
// Project 1
// bst.cpp [ISO C++11]

#include <iostream>
#include <string>
using namespace std;

#include "bst.h"

#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))

Tnode *BST::restoreBalance(Tnode *cur){
    switch(balanceFactor(cur)){
        case (-2):
            if(balanceFactor(cur->right) <= 0)
                cur = leftRotation(cur);
            else{
                cur->right = rightRotation(cur->right);
                cur = leftRotation(cur);
            }   
            break;
        case (2):
            if(balanceFactor(cur->left) >= 0)
                cur = rightRotation(cur);
            else{
                cur->left = leftRotation(cur->left);
                cur = rightRotation(cur);
            }
            break;
    }
    return cur;
}
Tnode *BST::remove(Tnode *cur, string akey){
    Tnode *ret = cur;
    if(cur != nullptr){
        if(akey < cur->key)
            cur->left = remove(cur->left, akey);
        else if(akey > cur->key)
            cur->right = remove(cur->right, akey);
        else{ // akey == cur->key
            if(cur->left == nullptr && cur->right == nullptr){
                delete cur;
                cur = nullptr;
                ret = cur;
            }else if(cur->left == nullptr && cur->right != nullptr){
                Tnode *tmp = cur->right;
                delete cur;
                ret = tmp;
            }else if(cur->left != nullptr && cur->right == nullptr){
                Tnode *tmp = cur->left;
                delete cur;
                ret = tmp;
            }else{ // cur->left != nullptr && cur->right != nullptr
                Tnode *tmp = getleftmost(cur->right);
                cur->key = tmp->key;
                cur->value = tmp->value;
                cur->right = remove(cur->right, cur->key);
                ret = cur;
            }
        }
    }
    int bf = balanceFactor(ret);
    if(bf < (-1) || bf > 1)
        ret = restoreBalance(ret);
    updateHeight(ret);
    updateSize(ret);
    return ret;
}
Tnode *BST::getleftmost(Tnode *cur){
    if(cur != nullptr){
        if(cur->left != nullptr)
            return getleftmost(cur->left);
        else
            return cur;
    }
    return nullptr;
}
void BST::printBF(Tnode* cur){
    if(cur != nullptr){
        printBF(cur->left);
        cout << balanceFactor(cur) << " ";
        printBF(cur->right);
    }
}
void BST::updateHeight(Tnode* cur){
    if(cur != nullptr){
        int hLeft = getHeight(cur->left);
        int hRight = getHeight(cur->right);
        int maxHeight = MAX(hLeft,hRight);
        cur->height = maxHeight + 1;
    }
}				
int BST::balanceFactor(Tnode* cur){
    if(cur != nullptr)
        return (getHeight(cur->left) - getHeight(cur->right));
    else
        return 0;
}				
Tnode* BST::rightRotation(Tnode *cur){
	Tnode *L = cur->left;
	cur->left = L->right;
	updateHeight(cur);
    updateSize(cur);
	L->right = cur;
	updateHeight(L);
    updateSize(L);
	return L;
}
Tnode* BST::leftRotation(Tnode *cur){
	Tnode *R = cur->right;
	cur->right = R->left;
	updateHeight(cur);
    updateSize(cur);
	R->left = cur;
	updateHeight(R);
    updateSize(R);
	return R;
}
void BST::heightPrint(Tnode *cur){
	if(cur != nullptr){
		heightPrint(cur->left);
		cout << cur->height << " ";
		heightPrint(cur->right);
	}
}
void BST::findPrint(Tnode *cur, string akey){
    if(cur != nullptr){
        if(cur->key == akey){
            int asize = (int)(cur->value).size();
            for(int i = 0; i < asize ; i++)
                cout << (cur->value)[i] << " ";
            cout << endl;
        }else if(akey < cur->key)
            findPrint(cur->left, akey);
        else
            findPrint(cur->right, akey);
    }
}//findPrint()
Tnode* BST::findNode(Tnode *cur, string key){
    if(cur != nullptr){
        if(cur->key != key)
            return findNode((key < cur->key) ? (cur->left) : (cur->right), key);
        else
            return cur;
    }else
        return nullptr;
}
void BST::print_inorder(Tnode *cur){
    if(cur != nullptr){
        print_inorder(cur->left);
        cout << "(" << cur->key << "){";
        int asize = (int)(cur->value).size();
        for(int i = 0; i < asize; i++)
            cout << (cur->value)[i] << " " ;
        cout << "} ";
        print_inorder(cur->right);
    }
}//print_inorder
void BST::clean(Tnode *cur){
    if(cur != nullptr){
        clean(cur->left);
        clean(cur->right);
        delete cur;
    }
}//clean()
Tnode *BST::insert(Tnode *cur, string akey, string aval){
    if(akey < cur->key){
        if(cur->left == nullptr)
            cur->left = new Tnode(akey, aval);
        else
            cur->left = insert(cur->left, akey, aval); //edited
    }else if(akey > cur->key){
        if(cur->right == nullptr)
            cur->right = new Tnode(akey, aval);
        else
            cur->right = insert(cur->right, akey, aval); //edited
    }else
        (cur->value).push_back(aval);
    int bf = balanceFactor(cur);
    if(bf < -1 || bf > 1)
        cur = restoreBalance(cur);
    updateHeight(cur);
    updateSize(cur);
    return cur;
}//insert()
string BST::findLCA(Tnode *cur, string akey1, string akey2){
    if(cur != nullptr){
        if(cur->key > akey1 && cur->key > akey2)
            return findLCA(cur->left, akey1, akey2);
        else if(cur->key < akey1 && cur->key < akey2)
            return findLCA(cur->right, akey1, akey2);
        else
            return cur->key;
    }else
        return "";
}
string BST::findKthSmallest(Tnode *cur, int k){
    int s = getSize(cur->left);
    if(k <= s)
        return findKthSmallest(cur->left, k);
    else if(k == s + 1)
        return cur->key;
    else
        return findKthSmallest(cur->right, (k-s-1));
}
void BST::printLongestPath(Tnode *cur){
    if(cur != nullptr){
        cout << cur->key << " ";
        if(cur->left != nullptr || cur->right != nullptr){
            if(getHeight(cur->left) >= getHeight(cur->right))
                printLongestPath(cur->left);
            else if(getHeight(cur->left) < getHeight(cur->right))
                printLongestPath(cur->right);
        }
    }
}
void BST::collecTree(Tnode *cur, vector<string> &result){
    if(cur != nullptr){
        collecTree(cur->left, result);
        result.push_back(cur->key);
        collecTree(cur->right, result);
    }
}
