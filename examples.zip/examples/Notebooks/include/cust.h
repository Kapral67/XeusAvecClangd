// Kapral, Maxwell
// CSCI 211
// mkapral
// Project 5
// cust.h

#ifndef CUST_H
#define CUST_H

#include <iostream>
#include <string>
#include <fstream>
#include <assert.h>
using namespace std;

class Cust{
    public:
        Cust(const string& name, bool robber, int arrival_time, int items);
        void print_entered(ostream &os, int clock);
        void print_done_shopping(ostream &os, int clock);
        void print_started_checkout(ostream &os, int clock, int checker);
        void print_done_checkout(ostream &os, int clock, int checker, int cash);
        int get_priority(){return m_arrival_time;}
        int get_items(){return m_items;}
        bool is_robber(){return m_robber;}
    private:
        string m_name;
        bool m_robber;
        int m_arrival_time;
        int m_items;
};

#endif