// Kapral, Maxwell
// CSCI 211
// mkapral
// pqueue.cpp
// Project 5

#include <iostream>

using namespace std;
#include "pqueue.h"
#include "cust.h"

//initialize m_head to NULL
Pqueue::Pqueue(){
    m_head = nullptr;
}

//return true if m_head is NULL
bool Pqueue::empty(){
    return (m_head == nullptr);
}

//free all memory
Pqueue::~Pqueue(){
    while(!empty()){
        dequeue();
    }
}

//return an integer; the length of the queue, 0 if empty
int Pqueue::length(){
    int exit = 0;
    if(!empty()){
        Node *ptr = m_head;
        while(ptr->m_next != nullptr){
            exit++;
            ptr = ptr->m_next;
        }
        exit++;
    }
    return exit;
}

//insert a new cust pointer onto the queue
void Pqueue::enqueue(Cust *cust, int priority){
    if(empty()){
        m_head = new Node(cust, priority, nullptr);
    }else{
        if(priority < m_head->m_priority){
            m_head = new Node(cust, priority, m_head);
        }else{
            Node *ptr = m_head;
            while(ptr->m_next != NULL && ptr->m_next->m_priority <= priority){
                ptr = ptr->m_next;
            }
            ptr->m_next = new Node(cust, priority, ptr->m_next);
        }
    }
}

//dequeue m_head; next object becomes m_head ,if none m_head is NULL
Cust* Pqueue::dequeue(){
    Cust *rvalue = m_head->m_cust;
    if(!empty()){
        Node *ptr = m_head;
        m_head = m_head->m_next;
        delete ptr;
    }
    return rvalue;
}

//without dequeuing, return priority of m_head
int Pqueue::first_priority(){
    int out = -1;
    if(!empty()){
        out = m_head->m_priority;
    }
    return out;
}