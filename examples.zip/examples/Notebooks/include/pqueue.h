// Kapral, Maxwell
// CSCI 211
// mkapral
// pqueue.h

#ifndef PQUEUE_H
#define PQUEUE_H

#include <iostream>
#include "cust.h"
using namespace std;

class Pqueue{
    public:
        Pqueue();
        ~Pqueue();
        int length();
        bool empty();
        void enqueue(Cust *cust, int priority);
        Cust* dequeue();
        int first_priority();
    private:
        class Node{
            public:
                Node(Cust *cust, int priority, Node *next){m_cust = cust; m_priority = priority; m_next = next;}
                Cust *m_cust;
                int m_priority;
                Node *m_next;
        };
        Node *m_head;
};

#endif