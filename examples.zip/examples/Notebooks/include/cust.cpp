// Kapral, Maxwel
// CSCI 211
// Project 5
// mkapral
// cust.cpp

#include <iostream>
#include <string>
#include <fstream>
#include <assert.h>
//#define NDEBUG    //assert control
using namespace std;
#include "cust.h"

//initialize customer member variables
Cust::Cust(const string& name, bool robber, int arrival_time, int items){
    m_name = name;
    m_robber = robber;
    m_arrival_time = arrival_time;
    m_items = items;
}

//print function for when a customers enters the store/simulation
void Cust::print_entered(ostream &os, int clock){
    assert(clock == m_arrival_time);
    os << clock << ": " << m_name << " entered store" << endl;
}

//print function for when a customer is done shopping at the store/simulation
void Cust::print_done_shopping(ostream &os, int clock){
    os << clock << ": " << m_name << " done shopping" << endl;
}

//print function for when the customer starts the checkout process in the store/simulation
void Cust::print_started_checkout(ostream &os, int clock, int checker){
    os << clock << ": " << m_name << " started checkout with checker " << checker << endl;
}

//print function for when the customer has finished the checkout process in the store/simulation
void Cust::print_done_checkout(ostream &os, int clock, int checker, int cash){
    string item_s = "items";
    if(m_items == 1){
        item_s = "item";
    }
    if(m_robber){
        os << clock << ": " << m_name << " stole $" << cash << " and " << m_items << " " << item_s << " from checker " << checker << endl;
    }else{
        cash = m_items*3;
        os << clock << ": " << m_name << " paid $" << cash << " for " << m_items << " " << item_s << " to checker " << checker << endl;
    }
}